package com.criador.senhas;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.SeekBar; // Importante para a barra
import android.app.Activity;
import android.widget.VideoView;
import android.net.Uri;
import android.media.MediaPlayer;
import android.widget.Toast;
import android.content.ClipboardManager;
import android.content.ClipData;
import android.content.Context;
import android.content.SharedPreferences;
import android.app.AlertDialog;
import android.content.DialogInterface;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Random;

public class MainActivity extends Activity {

    TextView tvPassword, tvTamanho;
    SeekBar seekBarTamanho;
    Button btnGenerate, btnSalvar, btnHistorico;
    VideoView videoFundo;

    String letrasRussas = "БГДЖИЛПФЦЧШЩЪЫЭЮЯ";
    String letrasChinesas = "山火水木土人刀力口国女心中日弓月";
    String letrasHebraicas = "אבגדהוזחטיכלמנסעפצקרשת";
    String letrasNormais = "abcdefABCDEFGHJKLMNPQRSTUVWXYZ";
    String numeros = "23456789";
    String caracteresEspeciais = "!@#$%&*()_+-=[]{}|;:.<>?";

    String ARQUIVO_PREFS = "CofreSenhas"; 

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(android.view.Window.FEATURE_NO_TITLE);
        setContentView(R.layout.layout_main);

        tvPassword = findViewById(R.id.tvPassword);
        tvTamanho = findViewById(R.id.tvTamanho);
        seekBarTamanho = findViewById(R.id.seekBarTamanho);
        btnGenerate = findViewById(R.id.btnGenerate);
        btnSalvar = findViewById(R.id.btnSalvar);
        btnHistorico = findViewById(R.id.btnHistorico);
        videoFundo = findViewById(R.id.videoFundo);

        // Configura a barra para começar no mínimo em 6 (segurança) e ir até 36
        // Como o SeekBar começa do 0, a gente faz um truque matemático
        seekBarTamanho.setMax(30); // Isso significa +6 = 36 max
        seekBarTamanho.setProgress(6); // Começa em 12 (6+6)

        // Atualiza o texto quando a pessoa mexe na barra
        seekBarTamanho.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                int tamanhoReal = progress + 6; // Mínimo de 6 caracteres
                tvTamanho.setText("Tamanho: " + tamanhoReal + " caracteres");
            }
            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {}
            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {}
        });

        // Vídeo de fundo
        try {
            String caminho = "android.resource://" + getPackageName() + "/" + R.raw.fundo;
            Uri uri = Uri.parse(caminho);
            videoFundo.setVideoURI(uri);
            videoFundo.setOnPreparedListener(new MediaPlayer.OnPreparedListener() {
                @Override
                public void onPrepared(MediaPlayer mp) {
                    mp.setLooping(true);
                    float videoRatio = mp.getVideoWidth() / (float) mp.getVideoHeight();
                    float screenRatio = videoFundo.getWidth() / (float) videoFundo.getHeight();
                    float scaleX = videoRatio / screenRatio;
                    if (scaleX >= 1f) videoFundo.setScaleX(scaleX);
                    else videoFundo.setScaleY(1f / scaleX);
                }
            });
            videoFundo.start();
        } catch (Exception e) {}

        btnGenerate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                gerarSenhaCustomizada();
            }
        });

        tvPassword.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                copiarTexto(tvPassword.getText().toString());
            }
        });

        btnSalvar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                salvarSenhaNoCofre();
            }
        });

        btnHistorico.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mostrarHistorico();
            }
        });
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (videoFundo != null) videoFundo.start();
    }

    private void gerarSenhaCustomizada() {
        int tamanhoEscolhido = seekBarTamanho.getProgress() + 6; // Pega o valor da barra
        
        Random random = new Random();
        StringBuilder senhaBruta = new StringBuilder();

        // 1. GARANTIA: Coloca pelo menos UM de cada tipo
        senhaBruta.append(letrasRussas.charAt(random.nextInt(letrasRussas.length())));
        senhaBruta.append(letrasChinesas.charAt(random.nextInt(letrasChinesas.length())));
        senhaBruta.append(letrasHebraicas.charAt(random.nextInt(letrasHebraicas.length())));
        senhaBruta.append(numeros.charAt(random.nextInt(numeros.length())));
        senhaBruta.append(caracteresEspeciais.charAt(random.nextInt(caracteresEspeciais.length())));
        senhaBruta.append(letrasNormais.charAt(random.nextInt(letrasNormais.length())));

        // Agora temos 6 caracteres garantidos.
        // Precisamos preencher o resto até chegar no tamanhoEscolhido.

        String tudoMisturado = letrasRussas + letrasChinesas + letrasHebraicas + numeros + caracteresEspeciais + letrasNormais;
        
        while (senhaBruta.length() < tamanhoEscolhido) {
            senhaBruta.append(tudoMisturado.charAt(random.nextInt(tudoMisturado.length())));
        }

        // EMBARALHA TUDO
        List<Character> caracteres = new ArrayList<>();
        for (char c : senhaBruta.toString().toCharArray()) caracteres.add(c);
        Collections.shuffle(caracteres);

        StringBuilder senhaFinal = new StringBuilder();
        for (char c : caracteres) senhaFinal.append(c);

        tvPassword.setText(senhaFinal.toString());
    }

    private void copiarTexto(String texto) {
        if(!texto.contains("Sua senha") && !texto.isEmpty()) {
            ClipboardManager clipboard = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
            ClipData clip = ClipData.newPlainText("Senha Copiada", texto);
            clipboard.setPrimaryClip(clip);
            Toast.makeText(getApplicationContext(), "Copiado! 📎", Toast.LENGTH_SHORT).show();
        }
    }

    private void salvarSenhaNoCofre() {
        String senhaAtual = tvPassword.getText().toString();
        if (senhaAtual.contains("Sua senha")) {
            Toast.makeText(this, "Gere uma senha primeiro!", Toast.LENGTH_SHORT).show();
            return;
        }

        SharedPreferences prefs = getSharedPreferences(ARQUIVO_PREFS, MODE_PRIVATE);
        String historicoAntigo = prefs.getString("lista_senhas", "");
        String novoHistorico = senhaAtual + "###" + historicoAntigo;

        SharedPreferences.Editor editor = prefs.edit();
        editor.putString("lista_senhas", novoHistorico);
        editor.apply();

        Toast.makeText(this, "Salvo no cofre! 🔒", Toast.LENGTH_SHORT).show();
    }

    private void mostrarHistorico() {
        SharedPreferences prefs = getSharedPreferences(ARQUIVO_PREFS, MODE_PRIVATE);
        String listaTexto = prefs.getString("lista_senhas", "");

        if (listaTexto.isEmpty()) {
            Toast.makeText(this, "Cofre vazio! Salve alguma senha antes.", Toast.LENGTH_SHORT).show();
            return;
        }

        String[] itensBrutos = listaTexto.split("###");
        final ArrayList<String> listaLimpa = new ArrayList<>();
        for(String s : itensBrutos) {
            if(!s.trim().isEmpty()) listaLimpa.add(s);
        }
        
        final String[] arrayFinal = listaLimpa.toArray(new String[0]);
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Toque na senha para COPIAR 📎");

        builder.setItems(arrayFinal, new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                String senhaEscolhida = arrayFinal[which];
                copiarTexto(senhaEscolhida);
            }
        });
        
        builder.setPositiveButton("Fechar", null);
        builder.setNegativeButton("Limpar Tudo", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                prefs.edit().clear().apply();
                Toast.makeText(MainActivity.this, "Histórico apagado.", Toast.LENGTH_SHORT).show();
            }
        });
        builder.create().show();
    }
}
